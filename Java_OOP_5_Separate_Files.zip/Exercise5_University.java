class University {
    static int totalStudents = 0;
    static int nextId = 1;

    String name;
    int id;

    University(String name) {
        this.name = name;
        this.id = nextId++;
        totalStudents++;
    }

    static int getTotalStudents() {
        return totalStudents;
    }

    int getMyId() {
        return this.id;
    }

    void display() {
        System.out.println("Student " + this.id + ": " +
                this.name + " (ID: " + this.id + ")");
    }
}

public class Main {
    public static void main(String[] args) {
        University[] students = new University[5];

        students[0] = new University("Alice");
        students[1] = new University("Bob");
        students[2] = new University("Charlie");
        students[3] = new University("Diana");
        students[4] = new University("Eve");

        System.out.println("Total Students: " +
                University.getTotalStudents());

        for (University s : students) {
            s.display();
        }
    }
}
