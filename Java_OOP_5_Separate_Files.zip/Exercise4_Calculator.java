class Calculator {
    int add(int a, int b) {
        System.out.println("[int,int] called");
        return a + b;
    }

    double add(double a, double b) {
        System.out.println("[double,double] called");
        return a + b;
    }

    int add(int a, int b, int c) {
        System.out.println("[int,int,int] called");
        return a + b + c;
    }

    String add(String a, String b) {
        System.out.println("[String,String] called");
        return a + b;
    }
}

public class Main {
    public static void main(String[] args) {
        Calculator calc = new Calculator();

        System.out.println(calc.add(2, 3));
        System.out.println(calc.add(2.5, 3.7));
        System.out.println(calc.add(1, 2, 3));
        System.out.println(calc.add("Hi,", "Bob"));
    }
}
