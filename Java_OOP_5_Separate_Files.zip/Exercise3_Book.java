class Book {
    String title, author;
    double price;
    int pages;

    Book() {
        this("Unknown", "Unknown", 0.0, 0);
    }

    Book(String t, String a) {
        this(t, a, 0.0, 0);
    }

    Book(String t, String a, double p, int pg) {
        title = t;
        author = a;
        price = p;
        pages = pg;
    }

    void display() {
        System.out.println(title + " by " + author +
                " | Rs" + price + " | " + pages + " pages");
    }
}

public class Main {
    public static void main(String[] args) {
        Book b1 = new Book();
        Book b2 = new Book("Java Basics", "Amit");
        Book b3 = new Book("AI & ML", "Priya", 599.0, 400);

        b1.display();
        b2.display();
        b3.display();
    }
}
