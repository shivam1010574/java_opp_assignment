class Rectangle {
    double length, width;

    void setDimensions(double l, double w) {
        length = l;
        width = w;
    }

    double area() {
        return length * width;
    }

    double perimeter() {
        return 2 * (length + width);
    }

    void display() {
        System.out.println("Length=" + length +
                " Width=" + width +
                " Area=" + area() +
                " Perimeter=" + perimeter());
    }
}

public class Main {
    public static void main(String[] args) {
        Rectangle r1 = new Rectangle();
        r1.setDimensions(5.0, 3.0);
        r1.display();

        Rectangle r2 = new Rectangle();
        r2.setDimensions(10.0, 7.5);
        r2.display();
    }
}
